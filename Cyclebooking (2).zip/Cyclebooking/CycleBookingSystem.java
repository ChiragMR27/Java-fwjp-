package com.Cyclebooking;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.imageio.ImageIO;
import javax.swing.*;

public class CycleBookingSystem extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    JTable CycleTable;
    JButton bookCycleButton;

    public CycleBookingSystem() {
        setTitle("Cycle Booking System");

        // Load the background image
        Image backgroundImage = null;
        try {
            backgroundImage = ImageIO.read(new File("C:\\Users\\Sachin\\Pictures\\BG2.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Scale the image to fit the frame size
        if (backgroundImage != null) {
            backgroundImage = backgroundImage.getScaledInstance(700, 500, Image.SCALE_SMOOTH);
        }

        // Create a JLabel to hold the image
        JLabel background = new JLabel(new ImageIcon(backgroundImage));
        setLayout(null); // Use null layout for custom positioning

        // Add background image label to frame
        background.setBounds(0, 0, 700, 500);
        add(background);

        // Initialize the button
        bookCycleButton = new JButton("Book a Bike");

        // Fetch bikes from the database and display in the table
        String[] columnNames = {"Cycle ID", "Cycle Name", "Model", "Price Per Day", "Availability"};
        String[][] data = fetchcycleData();

        CycleTable = new JTable(data, columnNames);
        JScrollPane sp = new JScrollPane(CycleTable);

        // Set bounds for components to be positioned on top of the background
        bookCycleButton.setBounds(100, 350, 150, 30);
        sp.setBounds(50, 50, 600, 250);

        // Add components to the background
        background.add(sp);
        background.add(bookCycleButton);

        // Add action listener for the button
        bookCycleButton.addActionListener(this);

        // Set JFrame properties
        setSize(700, 500); // Set the size to match the image size
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private String[][] fetchcycleData() {
        String[][] data = {};
        try {
            Connection con = DBConnection.getConnection();  // Ensure your DBConnection class is working properly
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery("SELECT * FROM cycle");

            rs.last();
            int rowCount = rs.getRow();
            data = new String[rowCount][5];
            rs.beforeFirst();

            int i = 0;
            while (rs.next()) {
                data[i][0] = String.valueOf(rs.getInt("Cycle_id"));
                data[i][1] = rs.getString("name");
                data[i][2] = rs.getString("model");
                data[i][3] = String.valueOf(rs.getDouble("price_per_day"));
                data[i][4] = rs.getBoolean("availability") ? "Available" : "Booked";
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bookCycleButton) {
            int selectedRow = CycleTable.getSelectedRow();
            if (selectedRow >= 0) {
                // Handle booking process
                String cycleId = (String) CycleTable.getValueAt(selectedRow, 0);
                new BookingForm(cycleId);
            } else {
                JOptionPane.showMessageDialog(null, "Please select a cycle to book.");
            }
        }
    }

    public static void main(String[] args) {
        new CycleBookingSystem();
    }
}
