package com.Cyclebooking;

public class Cycle {
    private int CycleId;
    private String name;
    private String model;
    private double pricePerDay;
    private boolean availability;
    
	public int getBikeId() {
		return CycleId;
	}
	public void setBikeId(int bikeId) {
		this.CycleId = bikeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public double getPricePerDay() {
		return pricePerDay;
	}
	public void setPricePerDay(double pricePerDay) {
		this.pricePerDay = pricePerDay;
	}
	public boolean isAvailability() {
		return availability;
	}
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

    
}
