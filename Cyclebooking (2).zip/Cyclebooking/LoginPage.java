package com.Cyclebooking;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.sql.*;

public class LoginPage extends JFrame implements ActionListener {
    
	private static final long serialVersionUID = 1L;
	
	JLabel l1, l2;
    JTextField tf1;
    JPasswordField p1;
    JButton btnLogin, btnRegister;

    public LoginPage() {
        setTitle("Cycle Booking System - Login");

        // Load and scale the background image
        Image backgroundImage = null;
        try {
            backgroundImage = ImageIO.read(new File("C:\\Users\\Sachin\\Pictures\\background.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (backgroundImage != null) {
            backgroundImage = backgroundImage.getScaledInstance(1000, 600, Image.SCALE_SMOOTH);
        }

        // Create a JLabel to hold the background image
        JLabel background = new JLabel(new ImageIcon(backgroundImage));
        background.setLayout(null); // Use null layout for absolute positioning

        // Set up components
        l1 = new JLabel("Email:");
        l1.setForeground(Color.WHITE);
        l2 = new JLabel("Password:");
        l2.setForeground(Color.WHITE);

        tf1 = new JTextField();
        p1 = new JPasswordField();

        btnLogin = new JButton("Login");
        btnRegister = new JButton("Register");

        // Set bounds for components
        l1.setBounds(350, 200, 100, 30);
        tf1.setBounds(450, 200, 200, 30);
        l2.setBounds(350, 250, 100, 30);
        p1.setBounds(450, 250, 200, 30);
        btnLogin.setBounds(450, 300, 100, 30);
        btnRegister.setBounds(550, 300, 100, 30);

        // Add components to the background
        background.add(l1);
        background.add(tf1);
        background.add(l2);
        background.add(p1);
        background.add(btnLogin);
        background.add(btnRegister);

        // Add background to the JFrame
        add(background);

        // Add action listeners
        btnLogin.addActionListener(this);
        btnRegister.addActionListener(this);

        // JFrame settings
        setSize(1000, 600);
        setLocationRelativeTo(null); // Center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnLogin) { // Login button
            try {
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE email=? AND password=?");
                ps.setString(1, tf1.getText());
                ps.setString(2, String.valueOf(p1.getPassword()));
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    JOptionPane.showMessageDialog(null, "Login Successful!");
                    new CycleBookingSystem(); // Proceed to booking system
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Login Details");
                }
            } catch (Exception ex) {
                System.out.println(ex);
            }
        } else if (e.getSource() == btnRegister) { // Register button
            new RegisterPage(); // Redirect to registration page
            dispose();
        }
    }

    public static void main(String[] args) {
        new LoginPage();
    }
}
