package com.Cyclebooking;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BookingForm extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    JLabel l1, l2;
    JTextField tf1, tf2;
    JButton btn1;

    public BookingForm(String bikeId) {
        setTitle("Cycle Booking Form");

        // Load the background image
        Image backgroundImage = null;
        try {
            backgroundImage = ImageIO.read(new File("C:\\Users\\Sachin\\Pictures\\BG2.jpg")); // Update path if needed
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Create a JLabel to hold the image
        JLabel background = new JLabel();
        if (backgroundImage != null) {
            background.setIcon(new ImageIcon(backgroundImage.getScaledInstance(900, 600, Image.SCALE_SMOOTH)));
        } else {
            background.setText("Background Image Not Found");
            background.setHorizontalAlignment(SwingConstants.CENTER);
            background.setForeground(Color.RED);
        }

        setLayout(null);

        // Add background image label to frame
        background.setBounds(0, 0, 900, 600);  // Match the frame size
        add(background);

        // Initialize labels and fields
        l1 = new JLabel("Booking Date (YYYY/MM/DD):");
        l2 = new JLabel("Return Date (YYYY/MM/DD):");

        l1.setForeground(Color.WHITE);
        l2.setForeground(Color.WHITE);

        tf1 = new JTextField();
        tf2 = new JTextField();

        btn1 = new JButton("Book");

        // Set bounds for components
        l1.setBounds(50, 50, 200, 30);
        l2.setBounds(50, 100, 200, 30);
        tf1.setBounds(250, 50, 150, 30);
        tf2.setBounds(250, 100, 150, 30);
        btn1.setBounds(150, 150, 100, 30);

        // Add components to the background
        background.add(l1);
        background.add(l2);
        background.add(tf1);
        background.add(tf2);
        background.add(btn1);

        // Add action listener for the button
        btn1.addActionListener(this);

        // Set JFrame properties
        setSize(900, 600); // Match the image size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        dateFormat.setLenient(false); // Disable lenient parsing

        try {
            // Parse dates from the text fields
            Date bookingDate = dateFormat.parse(tf1.getText().trim());
            Date returnDate = dateFormat.parse(tf2.getText().trim());
            Date currentDate = new Date();

            if (bookingDate.before(currentDate)) {
                JOptionPane.showMessageDialog(this, "Booking date cannot be in the past.", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (!returnDate.after(bookingDate)) {
                JOptionPane.showMessageDialog(this, "Return date must be after the booking date.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Bike booked successfully!\nBooking Date: " + tf1.getText() + "\nReturn Date: " + tf2.getText());
                dispose(); // Close the form
            }
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use YYYY/MM/DD.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new BookingForm("1"); // For testing purposes, pass a bike ID
    }
}
