package com.Cyclebooking;

import javax.swing.*;
import com.Cyclebooking.LoginPage;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import javax.imageio.ImageIO;

public class RegisterPage extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    JLabel l1, l2, l3, l4, l5;
    JTextField tf1, tf2, tf3, tf4;
    JPasswordField p1;
    JButton btnRegister;

    public RegisterPage() {
        setTitle("Cycle Booking System - Register");

        // Load the background image
        Image backgroundImage = null;
        try {
            backgroundImage = ImageIO.read(new File("C:\\Users\\Sachin\\Pictures\\BG2.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Scale the image to fit the frame size
        if (backgroundImage != null) {
            backgroundImage = backgroundImage.getScaledInstance(900, 600, Image.SCALE_SMOOTH);
        }

        // Create a JLabel to hold the image
        JLabel background = new JLabel(new ImageIcon(backgroundImage));
        setLayout(null); // Use null layout for custom positioning

        // Add background image label to frame
        background.setBounds(0, 0, 900, 600);
        add(background);

        // Initialize labels and text fields
        l1 = new JLabel("Name:");
        l2 = new JLabel("Email:");
        l3 = new JLabel("Password:");
        l4 = new JLabel("Phone:");
        l5 = new JLabel("Address:");

        tf1 = new JTextField();
        tf2 = new JTextField();
        p1 = new JPasswordField();
        tf3 = new JTextField();
        tf4 = new JTextField();

        btnRegister = new JButton("Register");

        // Set foreground color of labels to white
        l1.setForeground(Color.WHITE);
        l2.setForeground(Color.WHITE);
        l3.setForeground(Color.WHITE);
        l4.setForeground(Color.WHITE);
        l5.setForeground(Color.WHITE);

        // Set bounds for components to be positioned on top of the background
        l1.setBounds(50, 50, 100, 30);
        l2.setBounds(50, 100, 100, 30);
        l3.setBounds(50, 150, 100, 30);
        l4.setBounds(50, 200, 100, 30);
        l5.setBounds(50, 250, 100, 30);

        tf1.setBounds(150, 50, 200, 30);
        tf2.setBounds(150, 100, 200, 30);
        p1.setBounds(150, 150, 200, 30);
        tf3.setBounds(150, 200, 200, 30);
        tf4.setBounds(150, 250, 200, 30);

        btnRegister.setBounds(150, 300, 100, 30);

        // Add components to frame
        background.add(l1);
        background.add(l2);
        background.add(l3);
        background.add(l4);
        background.add(l5);
        background.add(tf1);
        background.add(tf2);
        background.add(p1);
        background.add(tf3);
        background.add(tf4);
        background.add(btnRegister);

        // Add action listener for button
        btnRegister.addActionListener(this);

        // Set JFrame properties
        setSize(900, 600); // Set the size to match the image size
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnRegister) {
            try {
                Connection con = DBConnection.getConnection();
                String query = "INSERT INTO users(name, email, password, phone, address) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, tf1.getText());
                ps.setString(2, tf2.getText());
                ps.setString(3, String.valueOf(p1.getPassword()));
                ps.setString(4, tf3.getText());
                ps.setString(5, tf4.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(null, "Registration Successful!");
                new LoginPage(); // Redirect to login page
                dispose();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new RegisterPage();
    }
}
